package bre.edu.unicid.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JSpinner;

public class Interface extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JTextField textField_1;
	private JLabel lblNewLabel_2;
	private JTextField textField_2;
	private JLabel lblNewLabel_3;
	private JTextField textField_3;
	private JLabel lblNewLabel_4;
	private JTextField textField_4;
	private JLabel lblNewLabel_5;
	private JTextField textField_5;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 748, 527);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("CA do Aluno");
		lblNewLabel.setBounds(36, 34, 165, 25);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(228, 36, 352, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Nome do Aluno");
		lblNewLabel_1.setBounds(36, 70, 145, 25);
		contentPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(228, 72, 352, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		lblNewLabel_2 = new JLabel("Email do Aluno");
		lblNewLabel_2.setBounds(36, 106, 182, 25);
		contentPane.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(228, 108, 352, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		lblNewLabel_3 = new JLabel("Data de Nacimento");
		lblNewLabel_3.setBounds(36, 142, 145, 14);
		contentPane.add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(228, 139, 352, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Endereco do Aluno");
		lblNewLabel_4.setBounds(36, 173, 145, 14);
		contentPane.add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(228, 170, 352, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		lblNewLabel_5 = new JLabel("Idade do Aluno");
		lblNewLabel_5.setBounds(36, 210, 165, 14);
		contentPane.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(228, 207, 352, 20);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		btnNewButton = new JButton("Novo");
		btnNewButton.setBounds(46, 243, 86, 23);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Salvar");
		btnNewButton_1.setBounds(153, 243, 86, 23);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Consultar");
		btnNewButton_2.setBounds(251, 243, 86, 23);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Alterar");
		btnNewButton_3.setBounds(357, 243, 93, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Apagar");
		btnNewButton_4.setBounds(460, 243, 98, 23);
		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Listar Todos");
		btnNewButton_5.setBounds(568, 243, 132, 23);
		contentPane.add(btnNewButton_5);
		
		textArea = new JTextArea();
		textArea.setBounds(36, 277, 631, 178);
		contentPane.add(textArea);
	}
}
