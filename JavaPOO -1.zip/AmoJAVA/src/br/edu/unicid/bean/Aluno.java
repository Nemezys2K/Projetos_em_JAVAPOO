package br.edu.unicid.bean;

public class Aluno {

}
